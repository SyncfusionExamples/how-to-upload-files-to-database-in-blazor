
window.OnRender = (id) => {
    var multilineObj = document.getElementById(id);
    multilineObj.setAttribute("rows","1");
    multilineObj.style.height = "auto";
    multilineObj.style.height = (multilineObj.scrollHeight - 7) + "px";
    multilineObj.addEventListener("input", function (e) {
        e.currentTarget.style.height = "auto";
        e.currentTarget.style.height = (e.currentTarget.scrollHeight) + "px";
    })
};